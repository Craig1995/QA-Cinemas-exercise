package com.qaconsulting.qacinemas;

public class Student {

    public String Student;

    public int price = 6;

        public Student(String name, int price){

        this.Student = Student;
        this.price = price;





        float[] Days = new float[7];
        Days[0] = 1.0f;
        Days[1] = 2.0f;
        Days[2] = 3.0f;
        Days[3] = 4.0f;      //Wednesday
        Days[4] = 5.0f;
        Days[5] = 6.0f;
        Days[6] = 7.0f;
    }
}
