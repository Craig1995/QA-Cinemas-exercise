package com.qaconsulting.qacinemas;

public class SumValues {
    public String SumValues;


}




